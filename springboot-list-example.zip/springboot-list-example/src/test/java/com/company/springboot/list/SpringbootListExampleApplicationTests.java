package com.company.springboot.list;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootListExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
