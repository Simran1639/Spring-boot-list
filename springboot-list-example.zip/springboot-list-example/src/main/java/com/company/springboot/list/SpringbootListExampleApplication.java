package com.company.springboot.list;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootListExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootListExampleApplication.class, args);
	}

}
