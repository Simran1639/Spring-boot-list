package com.company.springboot.list.entity;

import jakarta.persistence.Entity;

@Entity
public class Student {
	@Id
	private int id;
	private int age;
	private String name;
	private String email;
	

}
